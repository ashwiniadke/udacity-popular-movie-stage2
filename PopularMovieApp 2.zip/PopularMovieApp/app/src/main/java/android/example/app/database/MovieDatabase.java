package android.example.app.database;

import android.content.Context;
import android.util.Log;

import androidx.room.Room;
import androidx.room.RoomDatabase;

public abstract class MovieDatabase extends RoomDatabase {

    private static final String LOG_TAG = MovieDatabase.class.getSimpleName();
    private static final Object LOCK = new Object();
    private static final String DATABASE_NAME = "TmdbMovies";
    private static MovieDatabase movieDatabase;

    public static MovieDatabase getInstance(Context context) {
        if(movieDatabase == null) {
            synchronized (LOCK) {
                Log.d(LOG_TAG, "Creating new Database instance");
                movieDatabase = Room.databaseBuilder(context.getApplicationContext(), MovieDatabase.class, MovieDatabase.DATABASE_NAME).allowMainThreadQueries().build();
            }
        }

        Log.d(LOG_TAG, "Getting the database instance");
        return movieDatabase;
    }

    public abstract MovieDao movieDao();
}


