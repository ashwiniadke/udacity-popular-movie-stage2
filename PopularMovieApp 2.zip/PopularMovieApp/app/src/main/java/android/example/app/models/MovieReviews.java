package android.example.app.models;

import java.util.List;

public class MovieReviews {

    private List<Reviews> reviewList;

    public MovieReviews(List<Reviews> reviewList) {
        this.reviewList = reviewList;
    }

    public List<Reviews> getReviewList() {
        return reviewList;
    }

    public void setReviewList(List<Reviews> reviewList) {
        this.reviewList = reviewList;
    }
}
