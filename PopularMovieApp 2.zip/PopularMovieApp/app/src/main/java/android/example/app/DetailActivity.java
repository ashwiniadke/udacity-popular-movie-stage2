package android.example.app;

import android.content.Intent;
import android.example.app.Interface.MovieInterface;
import android.example.app.adapters.CustomCastAdapter;
import android.example.app.adapters.CustomReviewsAdapter;
import android.example.app.adapters.CustomTrailerAdapter;
import android.example.app.models.Cast;
import android.example.app.models.Movie;
import android.example.app.models.MovieCredits;
import android.example.app.models.MovieReviews;
import android.example.app.models.MovieTrailer;
import android.example.app.models.Reviews;
import android.example.app.models.Trailer;
import android.example.app.utils.APIClient;
import android.example.app.utils.MovieNetwork;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import com.squareup.picasso.OkHttp3Downloader;
import com.squareup.picasso.Picasso;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class DetailActivity extends AppCompatActivity {

    private static Retrofit retrofit;
    private static String API_KEY;
    public List<Trailer> trailers;
    public List<Reviews> reviews;
    public List<Cast> cast;
    public ImageView moviePoster;
    public TextView movieTitle;
    public TextView movieLanguage;
    public TextView moviePlot;
    public TextView movieReleaseDate;
    public TextView movieVoteAverage;
    public RecyclerView rvTrailer;
    public RecyclerView rvReviews;
    public RecyclerView rvCast;
    public TextView castNotAvailable;
    public TextView trailersNotAvailable;
    public TextView reviewsNotAvailable;
    public ImageView favBtn;

    private DetailsActivityViewModel viewModel;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        moviePoster = findViewById(R.id.iv_details_moviePoster);
        movieTitle = findViewById(R.id.tv_details_MovieTitle);
        movieLanguage = findViewById(R.id.tv_details_Language);
        moviePlot = findViewById(R.id.tv_details_plot);
        movieReleaseDate = findViewById(R.id.tv_details_releaseDate);
        movieVoteAverage = findViewById(R.id.tv_details_voteAverage);
        rvTrailer = findViewById(R.id.rv_trailer);
        rvReviews = findViewById(R.id.rv_reviews);
        rvCast = findViewById(R.id.rv_cast);
        castNotAvailable = findViewById(R.id.tv_cast_not_available);
        trailersNotAvailable = findViewById(R.id.tv_trailers_not_available);
        reviewsNotAvailable = findViewById(R.id.tv_reviews_not_available);
        favBtn = findViewById(R.id.iv_fav_btn);

        API_KEY = getResources().getString(R.string.API_KEY);
        viewModel = ViewModelProviders.of(this).get(DetailsActivityViewModel.class);
        bindSelectedMovieData();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void bindSelectedMovieData() {
        Intent intent = getIntent();
        Movie selectedMovie = intent.getParcelableExtra("SELECTED_MOVIE_TO_SEE_DETAILS");

        getMovieTrailers(selectedMovie.getMovieId());
        getMovieReviews(selectedMovie.getMovieId());
        getMovieCast(selectedMovie.getMovieId());

        movieTitle.setText(selectedMovie.getTitle());
        movieLanguage.setText(new StringBuilder(getString(R.string.Language_Title)).append(selectedMovie.getOriginalLanguage()));
        if (selectedMovie.getOverview() != null && !selectedMovie.getOverview().isEmpty()) {
            moviePlot.setText(selectedMovie.getOverview());
        } else {
            moviePlot.setText(getResources().getString(R.string.plotNotAvailable));
        }
        movieReleaseDate.setText(new StringBuilder(getString(R.string.Release_Date_Title)).append(selectedMovie.getReleaseDate()));
        movieVoteAverage.setText(new StringBuilder(getString(R.string.Rating_Title)).append(selectedMovie.getVoteAverage()));

        Picasso.Builder builder = new Picasso.Builder(this);
        builder.downloader(new OkHttp3Downloader(this));
        builder.build().load(this.getResources().getString(R.string.IMAGE_BASE_URL) + selectedMovie.getBackdropPath())
                .placeholder((R.drawable.gradient_background))
                .error(R.drawable.ic_launcher_background)
                .into(moviePoster);

        if (selectedMovie.isFavorite()) {
            favBtn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.favorite_selected));
        } else {
            favBtn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.favorite_unsel));
        }
        favBtn.setOnClickListener(v -> onFavButtonClicked(selectedMovie));
    }

    private void onFavButtonClicked(Movie selectedMovie) {
        if (selectedMovie.isFavorite()) {
            selectedMovie.setFavorite(false);
            favBtn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.favorite_unsel));
            viewModel.removeMovieFromFavorites(selectedMovie.getMovieId());
            Toast.makeText(this, R.string.Favorite_Removed, Toast.LENGTH_SHORT).show();
            navigateToFavoritesMovieScreen();
        } else {
            selectedMovie.setFavorite(true);
            favBtn.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.favorite_selected));
            Movie favMovie = new Movie(selectedMovie.getMovieId(), selectedMovie.getTitle(), selectedMovie.getOriginalTitle(),
                    selectedMovie.getOriginalLanguage(), selectedMovie.getOverview(), selectedMovie.getReleaseDate(),
                    selectedMovie.getVoteAverage(), selectedMovie.getBackdropPath(), selectedMovie.getPosterPath(),
                    selectedMovie.isFavorite());
            viewModel.addMovieToFavorites(favMovie);
            Toast.makeText(this, R.string.Favorite_Added, Toast.LENGTH_SHORT).show();
            navigateToFavoritesMovieScreen();
        }
    }

    private void navigateToFavoritesMovieScreen() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("FAV_MOVIE_KEY", true);
        startActivity(intent);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void getMovieCast(Integer id) {
        if (MovieNetwork.getInstance().isNetworkAvailable(this)) {
            if (retrofit == null) {
                retrofit = APIClient.getRetrofit();
            }
            MovieInterface movieService = retrofit.create(MovieInterface.class);
            Call<MovieCredits> call = movieService.getMovieCredits(id, API_KEY);
            call.enqueue(new Callback<MovieCredits>() {
                @Override
                public void onResponse(@NonNull Call<MovieCredits> call, @NonNull Response<MovieCredits> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        cast = response.body().getCast();
                        if (cast != null && !cast.isEmpty()) {
                            rvCast.setVisibility(View.VISIBLE);
                            castNotAvailable.setVisibility(View.GONE);
                            generateCreditsList(cast);
                        } else {
                            rvCast.setVisibility(View.GONE);
                            castNotAvailable.setVisibility(View.VISIBLE);
                        }
                    }
                }

                @Override
                public void onFailure(Call<MovieCredits> call, Throwable t) {
                    Toast.makeText(DetailActivity.this, R.string.Something_wrong_text, Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Log.i(getString(R.string.Network_Status_Not_Available), getString(R.string.Not_Available_Text));
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void getMovieReviews(Integer id) {
        if (MovieNetwork.getInstance().isNetworkAvailable(this)) {
            if (retrofit == null) {
                retrofit = APIClient.getRetrofit();
            }
            MovieInterface movieService = retrofit.create(MovieInterface.class);
            Call<MovieReviews> call = movieService.getMovieReviews(id, API_KEY, 1);
            call.enqueue(new Callback<MovieReviews>() {
                @Override
                public void onResponse(@NonNull Call<MovieReviews> call, @NonNull Response<MovieReviews> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        reviews = response.body().getReviewList();
                        if (reviews != null && !reviews.isEmpty()) {
                            rvReviews.setVisibility(View.VISIBLE);
                            reviewsNotAvailable.setVisibility(View.GONE);
                            generateReviewList(reviews);
                        } else {
                            rvReviews.setVisibility(View.GONE);
                            reviewsNotAvailable.setVisibility(View.VISIBLE);
                        }
                    }
                }

                @Override
                public void onFailure(Call<MovieReviews> call, Throwable t) {
                    Toast.makeText(DetailActivity.this, R.string.Something_wrong_text, Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Log.i(getString(R.string.Network_Status_Not_Available), getString(R.string.Not_Available_Text));
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    private void getMovieTrailers(Integer id) {
        if (MovieNetwork.getInstance().isNetworkAvailable(this)) {
            if (retrofit == null) {
                retrofit = APIClient.getRetrofit();
            }
            MovieInterface movieService = retrofit.create(MovieInterface.class);
            Call<MovieTrailer> call = movieService.getMovieTrailers(id, API_KEY);
            call.enqueue(new Callback<MovieTrailer>() {
                @Override
                public void onResponse(@NonNull Call<MovieTrailer> call, @NonNull Response<MovieTrailer> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        trailers = response.body().getTrailers();
                        if (trailers != null && !trailers.isEmpty()) {
                            rvTrailer.setVisibility(View.VISIBLE);
                            trailersNotAvailable.setVisibility(View.GONE);
                            generateTrailerList(trailers);
                        } else {
                            rvTrailer.setVisibility(View.GONE);
                            trailersNotAvailable.setVisibility(View.VISIBLE);
                        }
                    }
                }

                @Override
                public void onFailure(@NonNull Call<MovieTrailer> call, @NonNull Throwable t) {
                    Toast.makeText(DetailActivity.this, R.string.Something_wrong_text, Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Log.i(getString(R.string.Network_Status_Not_Available), getString(R.string.Not_Available_Text));
        }
    }

    private void generateCreditsList(List<Cast> cast) {
        CustomCastAdapter adapter = new CustomCastAdapter(this, cast);
        initCastAdapter(adapter);
    }

    private void generateReviewList(final List<Reviews> reviews) {
        CustomReviewsAdapter adapter = new CustomReviewsAdapter(this, reviews);
        initReviewsAdapter(adapter);
    }

    private void generateTrailerList(final List<Trailer> trailers) {
        CustomTrailerAdapter adapter = new CustomTrailerAdapter(this, trailers);
        initTrailersAdapter(adapter);
    }

    private void initCastAdapter(CustomCastAdapter adapter) {
        rvCast.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        rvCast.setAdapter(adapter);
    }

    private void initReviewsAdapter(CustomReviewsAdapter adapter) {
        rvReviews.setLayoutManager(new LinearLayoutManager(this));
        rvReviews.setAdapter(adapter);
    }

    private void initTrailersAdapter(CustomTrailerAdapter adapter) {
        rvTrailer.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        rvTrailer.setAdapter(adapter);
    }
}
