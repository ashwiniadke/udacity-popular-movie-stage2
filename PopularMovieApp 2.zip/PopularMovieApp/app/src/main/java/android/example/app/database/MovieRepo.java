package android.example.app.database;

import android.app.Application;
import android.example.app.models.Movie;
import android.example.app.utils.AppExecutors;

import androidx.lifecycle.LiveData;

import java.util.List;

public class MovieRepo {

    private MovieDao movieDao;
    private AppExecutors appExecutors;

    private LiveData<List<Movie>> movies;

    public MovieRepo(Application application) {
        movieDao = MovieDatabase.getInstance(application).movieDao();
        movies = movieDao.loadAllFavoriteMovies();

        appExecutors = AppExecutors.getExecutorInstance();
    }

    public LiveData<List<Movie>> loadAllFavoriteMovies() {
        return movies;
    }

    public void updateFavoriteMovie(Movie movie) {
        appExecutors.getDiskIO().execute(() -> movieDao.updateFavoriteMovie(movie));
    }

    public void addMovieToFavorites(Movie movie) {
        appExecutors.getDiskIO().execute(() -> movieDao.insertFavoriteMovie(movie));
    }

    public void deleteFavoriteMovie(int id) {
        appExecutors.getDiskIO().execute(() -> movieDao.deleteFavoriteMovie(id));
    }
}
