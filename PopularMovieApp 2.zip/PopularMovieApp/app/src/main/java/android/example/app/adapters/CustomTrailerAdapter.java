package android.example.app.adapters;

import android.content.Context;
import android.content.Intent;
import android.example.app.R;
import android.example.app.models.Trailer;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CustomTrailerAdapter extends RecyclerView.Adapter<CustomTrailerAdapter.TrailerViewHolder> {

    private Context context;
    private List<Trailer> trailers;

    public CustomTrailerAdapter(Context context, List<Trailer> trailers) {
        this.context = context;
        this.trailers = trailers;
    }

    @NonNull
    @Override
    public TrailerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull TrailerViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    class TrailerViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener{

        ImageView imageView;
        TextView name;
        ImageButton trailerPlayBtn;

        public TrailerViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.thumbnail);
            name = itemView.findViewById(R.id.tv_trailer_name);
            trailerPlayBtn = itemView.findViewById(R.id.play_button);
            trailerPlayBtn.setOnClickListener(this);
            itemView.setOnClickListener(this);
            itemView.setOnLongClickListener(this);
        }

        @Override
        public void onClick(View v) {

            Trailer video = trailers.get(getAdapterPosition());
            if(video!=null) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(context.getResources().getString(R.string.YOUTUBE_BASE_VIDEO_URL) + video.getKey()));
                if(intent.resolveActivity(context.getPackageManager()) != null) {
                    context.startActivity(intent);

                }else {
                    Toast.makeText(context,"Error Playing the video", Toast.LENGTH_SHORT).show();
                }
            }

        }

        @Override
        public boolean onLongClick(View v) {
            Trailer video = trailers.get(getAdapterPosition());
            if (video != null) {
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                Uri uri = Uri.parse(context.getResources().getString(R.string.YOUTUBE_BASE_VIDEO_URL) + video.getKey());
                sharingIntent.setType("text/plain");
                sharingIntent.putExtra(Intent.EXTRA_STREAM, uri);
                context.startActivity(Intent.createChooser(sharingIntent, "Share Video url using"));
            }
            return true;
        }
    }
}

