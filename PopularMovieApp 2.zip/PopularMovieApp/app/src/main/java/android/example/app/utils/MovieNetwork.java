package android.example.app.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.os.Build;
import android.util.Log;

final public class MovieNetwork {

    private boolean connected;
    private static MovieNetwork instance;

    public static MovieNetwork getInstance() {
        if(null != instance) {
            return instance;
        } else {
            instance = new MovieNetwork();
        }
        return instance;
    }

    private MovieNetwork() {

    }

    public boolean isNetworkAvailable(Context context) {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                networkInfo = connectivityManager.getActiveNetworkInfo();
            }
            connected = networkInfo !=null && networkInfo.isAvailable() && networkInfo.isConnected();
            return connected;
        } catch (Exception e) {
            System.out.println("CheckConnectivity Exception: " + e.getMessage());
            Log.v("connectivity", e.toString());

        }
        return connected;
    }
}
