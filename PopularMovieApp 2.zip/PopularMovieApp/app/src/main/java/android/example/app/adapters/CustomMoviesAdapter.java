package android.example.app.adapters;

import android.content.Context;
import android.content.Intent;
import android.example.app.DetailActivity;
import android.example.app.R;
import android.example.app.models.Movie;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CustomMoviesAdapter extends RecyclerView.Adapter<CustomMovieViewHolder> implements RecyclerViewClickListener {

    public static final String SELECTED_MOVIE_TO_SEE_DETAILS = "SelectedMovie";

    private List<Movie> dataList;
    private Context context;
    private RecyclerViewClickListener mListener;

    public CustomMoviesAdapter(List<Movie> dataList, Context context, RecyclerView recyclerView) {
        this.dataList = dataList;
        this.context = context;
        this.mListener = this;

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(context, 2));
    }


    @NonNull
    @Override
    public CustomMovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_grid_movie,parent,false);
        return new CustomMovieViewHolder(view, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomMovieViewHolder holder, int position) {
holder.bindMovie(dataList.get(position));
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public void setData(List<Movie> movies) {
        this.dataList = movies;
        notifyDataSetChanged();
    }

    public void clear() {
        this.dataList.clear();
        notifyDataSetChanged();
    }


    public void addAll(List<Movie> movies) {
        this.dataList.addAll(movies);
        notifyDataSetChanged();
    }

    @Override
    public void onClick(View view, int position) {
        Movie movie = dataList.get(position);
        Intent intent = new Intent(context, DetailActivity.class);
        intent.putExtra(SELECTED_MOVIE_TO_SEE_DETAILS, movie);
        context.startActivity(intent);
    }
}
