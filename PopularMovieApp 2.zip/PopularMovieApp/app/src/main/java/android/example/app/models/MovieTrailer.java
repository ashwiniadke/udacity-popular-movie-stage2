package android.example.app.models;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class MovieTrailer implements Parcelable {

    private List<Trailer> Trailers;

    public MovieTrailer(List<Trailer> trailers) {
        this.Trailers = trailers;
    }

    public MovieTrailer(Parcel parcel) {
        parcel.readTypedList(Trailers, Trailer.CREATOR);
    }

    public List<Trailer> getTrailers() {
        return Trailers;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedList(Trailers);

    }

    public static final Creator<MovieTrailer> CREATOR = new Creator<MovieTrailer>() {
        @Override
        public MovieTrailer createFromParcel(Parcel source) {
            return new MovieTrailer(source);
        }

        @Override
        public MovieTrailer[] newArray(int i) {
            return new MovieTrailer[i];
        }
    };
}
