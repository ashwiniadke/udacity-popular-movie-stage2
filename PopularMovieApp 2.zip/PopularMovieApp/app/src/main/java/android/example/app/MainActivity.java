package android.example.app;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.example.app.Interface.MovieInterface;
import android.example.app.adapters.CustomMoviesAdapter;
import android.example.app.models.Movie;
import android.example.app.models.MovieResponse;
import android.example.app.utils.APIClient;
import android.example.app.utils.MovieNetwork;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    private static String API_KEY;
    public ArrayList<Movie> movies;
    private int currentPage = 1;
    private MainActivityViewModel viewModel;
    private CustomMoviesAdapter adapter;
    private MovieInterface movieService;
    private static String actionBarTitle;
    private boolean mostPopularOptionChecked = true;
    private boolean topRatedOptionChecked = false;
    private ProgressBar progressBar;
    RecyclerView recyclerView;


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById (R.id.rv_main);
        progressBar = findViewById(R.id.progressBar);

        API_KEY = getResources().getString(R.string.API_KEY);
        movies = new ArrayList<>();
        adapter = new CustomMoviesAdapter( movies, this, recyclerView);
        recyclerView.setAdapter(adapter);
        viewModel = ViewModelProviders.of(this).get(MainActivityViewModel.class);

        viewModel.getFavMovies().observe(this,favorites -> {
            if (favorites != null && !mostPopularOptionChecked && !topRatedOptionChecked) {
                if(movies == null) {
                    movies = new ArrayList<>();
                } else {
                    adapter.clear();
                }
                adapter.addAll(favorites);

                if(movies.size() == 0) {
                    progressBar.setVisibility(View.INVISIBLE);
                    Toast.makeText(getApplicationContext(),R.string.FavoritesNotFound, Toast.LENGTH_SHORT).show();

                }
            }
        });


        movieService = APIClient.getRetrofit().create(MovieInterface.class);

        if(savedInstanceState !=null) {
            if(savedInstanceState.containsKey("MOVIES_LIST")) {
                progressBar.setVisibility(View.GONE);
                setTitle(savedInstanceState.getString("ACTIVITY_TITLE"));
                movies = savedInstanceState.getParcelableArrayList("MOVIES_LIST");
                adapter.clear();
                adapter.setData(movies);
            }

            if(savedInstanceState.containsKey("MOST_POPULAR_OPTION_CHECKED")) {
                mostPopularOptionChecked = savedInstanceState.getBoolean("MOST_POPULAR_OPTION_CHECKED");
            }

            if(savedInstanceState.containsKey("TOP_RATED_OPTION_CHECKED")) {
                topRatedOptionChecked = savedInstanceState.getBoolean("TOP_RATED_OPTION_CHECKED");
            }

        }


        if(savedInstanceState == null) {
            if(mostPopularOptionChecked) {
                progressBar.setVisibility(View.VISIBLE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    getPopularMovies();
                }
            } else if (topRatedOptionChecked) {
                progressBar.setVisibility(View.VISIBLE);
                getTopRatedMovies();
            }
        }
    }

    @SuppressLint("LongLogTag")
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void getPopularMovies() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if(MovieNetwork.getInstance().isNetworkAvailable(this)) {

                Call<MovieResponse> call = movieService.getPopularMovies(API_KEY,getResources().getString(R.string.LANGUAGE), currentPage);
                Log.i("Popular movies api", movieService.getPopularMovies(API_KEY,getResources().getString( R.string.LANGUAGE),1).request().url().toString());
                call.enqueue(new Callback<MovieResponse>() {
                    @Override
                    public void onResponse(retrofit2.Call<MovieResponse> call, Response<MovieResponse> response) {
                        if(response.isSuccessful()) {
                            progressBar.setVisibility(View.INVISIBLE);
                            if(response.body().getMovies() != null) {
                                Log.d(TAG, "Number of top rated movies:" + response.body().getMovies().size());
                                adapter.addAll(response.body().getMovies());
                            }
                        }

                    }

                    @Override
                    public void onFailure(retrofit2.Call<MovieResponse> call, Throwable t) {
                        progressBar.setVisibility(View.INVISIBLE);
                        Toast.makeText(MainActivity.this,getResources().getString(R.string.Something_wrong_text), Toast.LENGTH_SHORT).show();

                    }
                });
            } else {
                progressBar.setVisibility(View.INVISIBLE);
                Toast.makeText(MainActivity.this, getResources().getString(R.string.Network_Status_Not_Available), Toast.LENGTH_SHORT).show();
            }
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    @SuppressLint("LongLogTag")
    private void getTopRatedMovies() {
        if (MovieNetwork.getInstance().isNetworkAvailable(this)) {

            Call<MovieResponse> call = movieService.getTopratedMovies(API_KEY, getResources().getString(R.string.LANGUAGE), currentPage);
            Log.i("Top movies api", movieService.getTopratedMovies(API_KEY, getResources().getString(R.string.LANGUAGE), 1).request().url().toString());
            call.enqueue(new Callback<MovieResponse>() {
                @Override
                public void onResponse(Call<MovieResponse> call, Response<MovieResponse> response) {
                    if (response.isSuccessful()) {
                        progressBar.setVisibility(View.INVISIBLE);
                        if (response.body().getMovies() != null) {
                            Log.d(TAG, "Number of top rated movies received: " + response.body().getMovies().size());
                            adapter.addAll(response.body().getMovies());
                        }
                    }
                }

                @Override
                public void onFailure(Call<MovieResponse> call, Throwable t) {
                    progressBar.setVisibility(View.INVISIBLE);
                    Toast.makeText(MainActivity.this, getResources().getString(R.string.Something_wrong_text), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Log.i("Network Connection Status", "Not available");
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case R.id.topRated:
                progressBar.setVisibility(View.VISIBLE);
                mostPopularOptionChecked = false;
                topRatedOptionChecked = true;
                adapter.clear();
                getTopRatedMovies();
                setTitle(R.string.toprated_movies);
                actionBarTitle = getResources().getString(R.string.toprated_movies);
                break;

            case R.id.popular:
                mostPopularOptionChecked = true;
                topRatedOptionChecked = false;
                progressBar.setVisibility(View.VISIBLE);
                adapter.clear();
                getPopularMovies();
                setTitle(R.string.popular_movies);
                actionBarTitle = getResources().getString(R.string.popular_movies);
                break;

            case R.id.favorite:
                mostPopularOptionChecked = false;
                topRatedOptionChecked = false;
                progressBar.setVisibility(View.VISIBLE);
                adapter.clear();
                setTitle(R.string.favorite_movies);
                actionBarTitle = getResources().getString(R.string.favorite_movies);
                List<Movie> favMovies = viewModel.getFavMovies().getValue();
                if(favMovies != null && favMovies.size() > 0) {
                    progressBar.setVisibility(View.INVISIBLE);
                    adapter.addAll(favMovies);
                } else {
                    progressBar.setVisibility(View.INVISIBLE);
                    Toast.makeText(getApplicationContext(), R.string.FavoritesNotFound, Toast.LENGTH_SHORT).show();
                }
                break;

        }
        return super.onOptionsItemSelected(item);
        }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState, @NonNull PersistableBundle outPersistentState) {
        outState.putBoolean("MOST_POPULAR_OPTION_CHECKED", mostPopularOptionChecked);
        outState.putBoolean("TOP_RATED_OPTION_CHECKED", topRatedOptionChecked);
        outState.putParcelableArrayList("MOVIES_LIST", movies);
        outState.putString("ACTIVITY_TITLE", actionBarTitle);
        outState.putParcelable("RECYCLER_VIEW_LAYOUT_MANAGER_STATE", recyclerView.getLayoutManager().onSaveInstanceState());
        super.onSaveInstanceState(outState);
    }
}