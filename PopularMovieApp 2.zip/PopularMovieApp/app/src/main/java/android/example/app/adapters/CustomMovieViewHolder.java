package android.example.app.adapters;

import android.content.Context;
import android.example.app.R;
import android.example.app.models.Movie;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.OkHttp3Downloader;
import com.squareup.picasso.Picasso;


public class CustomMovieViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    private Context mContext;

    TextView movieTitle;

    ImageView coverImage;

    TextView releaseDate;

    private RecyclerViewClickListener clickListener;

    public CustomMovieViewHolder(@NonNull View itemView, RecyclerViewClickListener listener) {
        super(itemView);
        movieTitle = itemView.findViewById(R.id.tvMovieTitle);
        coverImage = itemView.findViewById(R.id.ivMovieImage);
        releaseDate = itemView.findViewById(R.id.tvReleaseDate);
        mContext = itemView.getContext();
        itemView.setOnClickListener(this);
        this.clickListener = listener;
    }

    void bindMovie(Movie movie) {
        StringBuilder releaseComment = new StringBuilder().append(mContext.getResources().getString(R.string.Release_Date_Title));
        releaseComment.append(movie.getReleaseDate());

        movieTitle.setText(movie.getOriginalTitle());
        releaseDate.setText(releaseComment);
        Picasso.Builder builder = new Picasso.Builder(mContext);
        builder.downloader(new OkHttp3Downloader(mContext));
        builder.build().load(mContext.getResources().getString(R.string.IMAGE_BASE_URL) + movie.getPosterPath())
                .placeholder((R.drawable.gradient_background))
                .error(R.drawable.ic_launcher_background)
                .into(coverImage);

    }
    @Override
    public void onClick(View v) {
        clickListener.onClick(v, getAdapterPosition());

    }
}
