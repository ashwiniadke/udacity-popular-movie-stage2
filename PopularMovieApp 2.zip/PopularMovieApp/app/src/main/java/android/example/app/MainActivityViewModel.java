package android.example.app;

import android.app.Application;
import android.example.app.database.MovieRepo;
import android.example.app.models.Movie;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

public class MainActivityViewModel extends AndroidViewModel {

    private static final String TAG = MainActivityViewModel.class.getSimpleName();
    private LiveData<List<Movie>> favMovies;

   public  MainActivityViewModel (@NonNull Application application) {
       super(application);
       MovieRepo movieRepo = new MovieRepo(application);
       Log.d(TAG, "Getting tasks from database via ViewModel");
       favMovies = movieRepo.loadAllFavoriteMovies();

   }

   public LiveData<List<Movie>> getFavMovies() {
       return favMovies;
   }
}
