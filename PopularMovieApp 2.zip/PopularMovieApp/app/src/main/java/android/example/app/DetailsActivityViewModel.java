package android.example.app;

import android.app.Application;
import android.example.app.database.MovieRepo;
import android.example.app.models.Movie;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

public class DetailsActivityViewModel extends AndroidViewModel {

    private MovieRepo movieRepo;

    public DetailsActivityViewModel(@NonNull Application application) {
        super(application);
        movieRepo = new MovieRepo(application);
    }

    public void addMovieToFavorites(Movie movie) {
        movieRepo.addMovieToFavorites(movie);
    }

    public void removeMovieFromFavorites(int id) {
        movieRepo.deleteFavoriteMovie(id);
    }
}
