package android.example.app.models;

import java.util.ArrayList;

public class MovieResponse {

    private ArrayList<Movie> movies;

    public MovieResponse(ArrayList<Movie> movies) {
        this.movies = movies;
    }

    public ArrayList<Movie> getMovies() {
        return movies;
    }

    public void setMovies(ArrayList<Movie> movies) {
        this.movies = movies;
    }
}
